# Source for the seven public File Manager 1.0 media DLLs

This local review bundle corresponds to `packaging/v53-approved-media-inputs.zip`
(SHA-256 `2D0D037BD8B6DB9E9D24A8EFA8FDDD0A7DED197E2041201E933044F1DB0DA588`) at File Manager source commit `b98b78eee77ff8316cbf9d0dd603a32856816622`:
https://github.com/mpkfresh/File-Manager-1.0/tree/b98b78eee77ff8316cbf9d0dd603a32856816622

That archive contains exactly five FFmpeg DLLs, `Qt6Multimedia.dll`, and
`multimedia/ffmpegmediaplugin.dll`. `checksums.sha256` binds the two source
members below to this review bundle. The seven DLL hashes are in the public
`packaging/ffmpeg-1.0-v53-approved-input.json` at the same commit.

`source/FileManager-1.0-media-source-REVIEW-20261028.zip` contains FFmpeg
n7.1.5, Qt Multimedia 6.11.2, and zlib 1.3.1 source archives, the two local
patches, license texts, notices, and build/relink instructions. The separate
`V53_MEDIA_BUILD_ADDENDUM.md` records the required Vulkan development input.
Verify the nested companion's own `checksums.sha256` before using it.

The executable Windows recipe is `tools/Build-ReviewedMediaFromCompanion.ps1`
at V53 build-source commit `42450e674dd5b25fc3d92b499310a8dcf44b05c8`. Hosted run 41370308365 completed
that recipe and produced the seven approved DLL hashes. The raw hosted build
report was not retained locally. A fresh hosted rebuild in run 42145915169
produced seven different hashes, with matching file sizes; the source inputs
alone do not prove bit-for-bit reproducibility of the retained DLLs.

This bundle addresses only the seven media DLLs in the named public archive.
It is not a source or rights claim for the rest of a future MSI or portable
package. It is a local review candidate until separately approved for public
distribution; it does not authorize signing or a 1.0 release.
