# File Manager 1.0 media source v3 build addendum — review candidate

This is a review-only supplement to the immutable
`FileManager-1.0-media-source-REVIEW-20261028.zip` (27,762,613 bytes,
SHA-256 `6295B6E95DFDA0954F0245FC9D6F4DFF734A89E8BEAF8F14E2C92D553A12FDF1`).
That ZIP is the source input consumed by the reviewed V53 hosted recipe. Its
inner `checksums.sha256` has SHA-256
`5123D85407AD0E077A627945E22F220F4D2778DEE1459C610ECB736BA7F66D13`.
Keep those bytes unchanged when reproducing the V53 source build. Check both
hashes before using the archive.

The ZIP's `build/media-source-and-relink.md` is a host-neutral guide. Its Qt
CMake example omits one necessary build input: LunarG Vulkan SDK 1.4.357.0.
The V53 hosted workflow downloaded the official Windows SDK installer with
SHA-256 `81F474711E9042F4CD22B31B2F7A8870DB2E428B21586FB43DD80150BE97310D`,
used a temporary copy-only installation, and hashed the resulting
`Include/vulkan/vulkan.h` and `Lib/vulkan-1.lib`. It passed their hashes to
the recipe, set `VULKAN_SDK` to the copied SDK folder, and configured Qt with
`-DVulkan_INCLUDE_DIR=<sdk>/Include` and
`-DVulkan_LIBRARY=<sdk>/Lib/vulkan-1.lib`. A reproducing build needs those
inputs in addition to the Qt kit and matching ShaderTools component.

Use the executable Windows recipe and safe archive extractor in public
File Manager source commit `42450e674dd5b25fc3d92b499310a8dcf44b05c8`:

- [Build-ReviewedMediaFromCompanion.ps1](https://github.com/mpkfresh/File-Manager-1.0/blob/42450e674dd5b25fc3d92b499310a8dcf44b05c8/tools/Build-ReviewedMediaFromCompanion.ps1)
- [Extract-PinnedMediaArchive.py](https://github.com/mpkfresh/File-Manager-1.0/blob/42450e674dd5b25fc3d92b499310a8dcf44b05c8/tools/Extract-PinnedMediaArchive.py)

The recipe itself requires the v3 inner checksum-list hash above. It extracts
and verifies the FFmpeg n7.1.5, Qt Multimedia 6.11.2 and zlib 1.3.1 sources;
applies both supplied patches with LF and zero-context Git settings; builds
zlib, FFmpeg and Qt Multimedia; and records the seven resulting media hashes.
[V53 hosted run 41370308365](https://github.com/mpkfresh/File-Manager-1.0/actions/runs/41370308365)
completed that recipe on a fresh Windows runner. The raw hosted build report
was not retained locally, but the unsigned V53 package's seven media hashes
matched its review-only provenance record and the source input hashes above.

The separate v4 companion corrects the written guide but has a **different**
checksum list. The V53 public recipe rejects v4 without a deliberate recipe
change and another build. For the currently reviewed bytes, keep v3 as the
source input and supply this addendum beside it. Before a public source offer,
review the final signed media hashes, notices, executable recipe, source
download page, and the inner v3 review-only wording together. This addendum
does not itself approve publication or establish that the final signed files
match V53.
